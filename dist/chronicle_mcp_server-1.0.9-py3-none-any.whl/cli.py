import sys
import json
import argparse
import shutil
from pathlib import Path

# Target configuration paths for different apps on macOS
CURSOR_CONFIG_PATH = Path.home() / ".cursor" / "mcp.json"
CLAUDE_CONFIG_PATH = Path.home() / ".claude.json"
SETTINGS_FILE_PATH = Path.home() / ".chronicle_settings.json"

def split_export_file(export_file_path, output_dir_path):
    """Parses a monolithic chat export JSON and splits it into individual neat files."""
    export_path = Path(export_file_path).expanduser().resolve()
    out_dir = Path(output_dir_path).expanduser().resolve()
    
    if not export_path.exists():
        print(f"Error: The export file '{export_path}' does not exist.", file=sys.stderr)
        return

    out_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        with open(export_path, "r", encoding="utf-8") as f:
            conversations = json.load(f)
            
        if isinstance(conversations, dict):
            conversations = conversations.get("conversations", [conversations])
        elif not isinstance(conversations, list):
            conversations = [conversations]

        print(f"Parsing '{export_path.name}'... Found {len(conversations)} distinct conversation threads.")
        
        saved_count = 0
        for idx, chat in enumerate(conversations):
            title = chat.get("title", f"chat_session_{idx}").strip().replace("/", "_").replace(" ", "_")
            title = (title[:40] + "..") if len(title) > 40 else title
            
            output_file = out_dir / f"{title}.json"
            
            with open(output_file, "w", encoding="utf-8") as out_f:
                json.dump(chat, out_f, indent=2)
            saved_count += 1
            
        print(f" Success! Extracted and stored {saved_count} structured chat logs inside: {out_dir}")
        
    except Exception as e:
        print(f"Failed to split file: {e}", file=sys.stderr)

def get_mcp_config():
    """Dynamically locates the absolute path of uvx to prevent ENOENT path errors."""
    # Look up where uvx lives on this specific Mac (e.g., /opt/homebrew/bin/uvx)
    uvx_path = shutil.which("uvx")
    
    # Fallback to loose "uvx" if for some reason shutil can't find it
    if not uvx_path:
        uvx_path = "uvx"
        
    return {
        "command": str(uvx_path),
        "args": ["chronicle-mcp-server"]
    }

def update_json_config(file_path, app_name):
    """Safely injects the chronicle-mcp configuration into the target application JSON."""
    try:
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        if file_path.exists():
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except json.JSONDecodeError:
                data = {}
        else:
            data = {}

        if "mcpServers" not in data:
            data["mcpServers"] = {}

        data["mcpServers"]["chronicle-mcp"] = get_mcp_config()

        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
            
        print(f" Successfully configured chronicle-mcp inside {app_name}!")
    except Exception as e:
        print(f"Error updating {app_name} configuration: {e}", file=sys.stderr)

def set_chats_folder(folder_path):
    """Saves the user's custom chats folder path to a local settings file."""
    resolved_path = Path(folder_path).expanduser().resolve()
    settings = {"chats_folder": str(resolved_path)}
    
    with open(SETTINGS_FILE_PATH, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2)
    print(f" Successfully set chats directory to: {resolved_path}")

def main():
    parser = argparse.ArgumentParser(description="Chronicle MCP Command Line Interface")
    
    # Global flag options
    parser.add_argument("--chats-folder", type=str, help="Set the default local storage directory for chat transcripts")
    
    subparsers = parser.add_subparsers(dest="command")

    # Subcommand: add
    add_parser = subparsers.add_parser("add", help="Add chronicle MCP to a specified application environment")
    add_parser.add_argument("app", choices=["cursor", "claude"], help="The target application interface")
    
    # Subcommand: split
    split_parser = subparsers.add_parser("split", help="Split a combined conversation export into separate files")
    split_parser.add_argument("file", type=str, help="Path to the monolithic conversation.json file")
    split_parser.add_argument("--out", type=str, required=True, help="Target folder directory to save split chats")

    args = parser.parse_args()

    # 1. Handle global flag
    if args.chats_folder:
        set_chats_folder(args.chats_folder)
        return

    # 2. Handle subcommands
    if args.command == "split":
        split_export_file(args.file, args.out)
        return
    elif args.command == "add":
        if args.app == "cursor":
            update_json_config(CURSOR_CONFIG_PATH, "Cursor Desktop")
        elif args.app == "claude":
            update_json_config(CLAUDE_CONFIG_PATH, "Claude Code")
        return

    # Default fallback: Boot the core server if no subcommands or configuration flags are requested
    import chat_server
    chat_server.mcp.run()

if __name__ == "__main__":
    main()